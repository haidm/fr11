<?php
class Datdt_Album_IndexController extends Mage_Core_Controller_Front_Action
{

    public function indexAction()
    {
       echo "<h1 style='color: red;text-align: center'>test controller</h1>";
    }

}

?>
