<?php

class Datdt_Album_Helper_Data extends Mage_Core_Helper_Abstract {

}