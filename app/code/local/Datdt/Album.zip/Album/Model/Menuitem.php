<?php
class Datdt_Album_Model_Menuitem extends Mage_Core_Model_Abstract
{

    protected function _construct()
    {
        $this->_init('album/menuitem1');
    }

}